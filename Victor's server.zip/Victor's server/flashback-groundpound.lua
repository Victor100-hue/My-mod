-- name: Flashback Ground Pound
-- description: \\#96C8FE\\Flashabck \\#00B8E6\\G\\#FFCC0A\\r\\#CC2D2D\\o\\#5EB843\\u\\#FFCC0A\\n\\#CC2D2D\\d \\#5EB843\\P\\#FFCC0A\\o\\#00B8E6\\u\\#5EB843\\n\\#CC2D2D\\d \\#FFFFFF\\ \n \nMade by: \\#FF75D2\\OneCalledRPG\\#FFFFFF\\ \nInspired by: \\#3278FF\\SM64 Plus \\#FFFFFF\\and \\#96C8FE\\Super Mario Flashback\\#FFFFFF\\ \n \nTweaks the groundpound a bit, allows Mario to recover faster from ground pounds, land directly into a crouch, or initiate a slide kick.

enableFlashbackGP = false

function flashback_gp(m)
    if not enableFlashbackGP then return end

    if m.action == ACT_GROUND_POUND_LAND then
        if m.actionTimer >= 1 then
            if (m.input & INPUT_Z_DOWN) ~= 0 then
                if (m.input & INPUT_NONZERO_ANALOG) ~= 0 then
                    m.faceAngle.y = m.intendedYaw
                    set_mario_action(m, ACT_SLIDE_KICK, 0)
                    set_mario_animation(m, MARIO_ANIM_SLIDE_KICK)
                    play_mario_sound(m, CHAR_SOUND_HOOHOO, 1)
                    m.forwardVel = 50
                    m.vel.y = 15
                else
                    m.action = ACT_CROUCHING
                end
            else
                m.action = ACT_BACKWARD_ROLLOUT
                m.vel.y = 40
            end
        end
        m.actionTimer = m.actionTimer + 1
    end
end

hook_event(HOOK_MARIO_UPDATE, flashback_gp)

hook_chat_command("flashbackgp", "Enables the ground pound from Super Mario Flashback (more specifically, it's variant from SM64 Plus)",
function (msg)
	enableFlashbackGP = not enableFlashbackGP
	play_sound(SOUND_MENU_STAR_SOUND, gMarioStates[0].pos)
    return true
end)