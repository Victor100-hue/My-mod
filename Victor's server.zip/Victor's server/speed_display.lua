-- name: Speed Display
-- description: Shows how fast you are going.


function hud_speed()
    djui_hud_set_font(FONT_HUD)
    local scale = 3.00

    local x = 800
    local y = 100

    local background = 0.0
    djui_hud_set_color(255 * background, 0, 0, 128);

    djui_hud_set_color(255, 255, 255, 255);
    djui_hud_print_text(string.format("Speed %.0f", gMarioStates[0].forwardVel), x, y, scale)
end
    
function on_hud_render()
    hud_speed()
end

hook_event(HOOK_ON_HUD_RENDER, on_hud_render)
