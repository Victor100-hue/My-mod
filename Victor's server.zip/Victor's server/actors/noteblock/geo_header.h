extern const GeoLayout noteblock_geo[];
extern Lights1 noteblock_f3dlite_material_lights;
extern u8 noteblock__0_rgba16[];
extern Vtx noteblock_000_offset_mesh_layer_1_vtx_0[22];
extern Gfx noteblock_000_offset_mesh_layer_1_tri_0[];
extern Gfx mat_noteblock_f3dlite_material[];
extern Gfx noteblock_000_offset_mesh_layer_1[];
