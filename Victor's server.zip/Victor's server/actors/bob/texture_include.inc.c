Gfx bob_dl__0_rgba16_aligner[] = {gsSPEndDisplayList()};
u8 bob_dl__0_rgba16[] = {
	#include "levels/bob/_0.rgba16.inc.c"
};

Gfx bob_dl__1_rgba16_aligner[] = {gsSPEndDisplayList()};
u8 bob_dl__1_rgba16[] = {
	#include "levels/bob/_1.rgba16.inc.c"
};

Gfx bob_dl__2_rgba16_aligner[] = {gsSPEndDisplayList()};
u8 bob_dl__2_rgba16[] = {
	#include "levels/bob/_2.rgba16.inc.c"
};

Gfx bob_dl__3_rgba16_aligner[] = {gsSPEndDisplayList()};
u8 bob_dl__3_rgba16[] = {
	#include "levels/bob/_3.rgba16.inc.c"
};

Gfx bob_dl__4_rgba16_aligner[] = {gsSPEndDisplayList()};
u8 bob_dl__4_rgba16[] = {
	#include "levels/bob/_4.rgba16.inc.c"
};

Gfx bob_dl__5_rgba16_aligner[] = {gsSPEndDisplayList()};
u8 bob_dl__5_rgba16[] = {
	#include "levels/bob/_5.rgba16.inc.c"
};

Gfx bob_dl__6_rgba16_aligner[] = {gsSPEndDisplayList()};
u8 bob_dl__6_rgba16[] = {
	#include "levels/bob/_6.rgba16.inc.c"
};

