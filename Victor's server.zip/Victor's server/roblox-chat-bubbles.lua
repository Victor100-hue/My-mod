-- name: Roblox Chat Bubbles
-- description: Displays chat messages as bubbles above the players' heads, by Caec.

msglist = {}
timerlist = {}
for i=0,15 do timerlist[gMarioStates[i]] = 0 end

function display_bubble(m, c)
    djui_hud_set_resolution(RESOLUTION_N64); djui_hud_set_font(FONT_NORMAL);
    local out = { x = m.marioObj.header.gfx.pos.x, y = m.pos.y + 210, z = m.marioObj.header.gfx.pos.z }
    djui_hud_world_pos_to_screen_pos(out, out)

    local scale = 0.4 - (vec3f_dist(m.pos, gMarioStates[0].pos))/16384

    if scale > 0 then
        local measure = djui_hud_measure_text(c) * (scale/2)
        djui_hud_set_color(255,255,255,127); djui_hud_render_rect(out.x - measure, out.y, measure*2, 32*scale); djui_hud_set_color(0,0,0,255); djui_hud_print_text(c, out.x - measure, out.y, scale);
    end
end

function render_bubbles()
    for i=0,15 do
        if msglist[gMarioStates[i]] ~= nil and gNetworkPlayers[i].currActNum == gNetworkPlayers[0].currActNum and gNetworkPlayers[i].currAreaIndex == gNetworkPlayers[0].currAreaIndex and gNetworkPlayers[i].currLevelNum == gNetworkPlayers[0].currLevelNum then
            display_bubble(gMarioStates[i], msglist[gMarioStates[i]])
        else
            msglist[gMarioStates[i]] = nil
        end
    end
end

function addmsg(m, c)
    msglist[m] = c; timerlist[m] = 255;
end

function clearmsgs()
    for i=0,15 do msglist[gMarioStates[i]] = nil end
end

function updatetimer()
    for i=0,15 do
        if timerlist[gMarioStates[i]] > 0 then
            timerlist[gMarioStates[i]] = timerlist[gMarioStates[i]] - 1
        else
            msglist[gMarioStates[i]] = nil
        end
    end
end

hook_event(HOOK_ON_CHAT_MESSAGE, addmsg)
hook_event(HOOK_ON_HUD_RENDER, render_bubbles)
hook_event(HOOK_ON_WARP, clearmsgs)
hook_event(HOOK_UPDATE, updatetimer)
