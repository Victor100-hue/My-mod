-- name: Dark's Server Commands
-- description: Mod by, well, DemoDark, like is that not obvious?\nCommands of this version are "/kill", "/fly", and "/freeze". \nCredits:\nMe\nSunk

local is_frozen = false
local frozen_pos = {x = 0, y = 0, z = 0}

function fly_chat_command(msg)
	local m = gMarioStates[0]
	if not network_is_server() then
    djui_chat_message_create("You are not the host. Ask the person who runs things to drop you to a wing cap box or something")
    return true
end
    if msg == "on" then
        m.flags = m.flags | MARIO_WING_CAP
    elseif msg == "off" then
        m.flags = m.flags & ~MARIO_WING_CAP
    end
    return true
end

---@param m MarioState
local function is_player_active(m)
    if not m then return end
    local np = gNetworkPlayers[m.playerIndex]
    ---@type NetworkPlayer
    local local_np = gNetworkPlayers[0]
    -- If the selected player is yourself
    if local_np.type == 0 and m == gMarioStates[0] then return true end
    if np == network_player_from_global_index(0) and gServerSettings.headlessServer == 1 then return false end
    if np.type ~= NPT_LOCAL then
        if not np.connected then return false end
        if not local_np then return end
        local levelAreaMismatch =
            (np.currCourseNum   ~= local_np.currCourseNum
            or np.currActNum    ~= local_np.currActNum
            or np.currLevelNum  ~= local_np.currLevelNum
            or np.currAreaIndex ~= local_np.currAreaIndex)
        if levelAreaMismatch then return false end
    end
    return true
end

---@param name string
---@return string
local function strip_colors(name)
    local string = ''
    local inSlash = false
    for i = 1, #name do
        local character = name:sub(i,i)
        if character == '\\' then
            inSlash = not inSlash
        elseif not inSlash then
            string = string .. character
        end
    end
    return string
end

---@param player_name string
---@return integer | nil
local function get_global_index_from_name(player_name)
    for i = 0, MAX_PLAYERS - 1, 1 do
        if gNetworkPlayers[i].connected then
            if (strip_colors(gNetworkPlayers[i].name)):lower() == (player_name):lower() then
                i = network_global_index_from_local(i)
                return i
            end
        end
    end
    return nil
end

local function toggle_frozen()
    is_frozen = not is_frozen -- Toggle
    vec3f_copy(frozen_pos, gMarioStates[0].pos)
end

---@param m MarioState
local function freeze_before_mario_update(m)
    if is_frozen then
        local controller = m.controller
        vec3f_copy(m.pos, frozen_pos)
        vec3f_copy(m.vel, {x = 0, y = 0, z = 0})
        controller.buttonPressed = 0
        controller.buttonDown = 0
        controller.stickX = 0
        controller.stickY = 0
    end
end

---@param datatable table
local function freeze_packet_recieve(datatable)
    if datatable.freeze then
        toggle_frozen()
    end
end

local function check_valid_player(msg, ptr)
    if network_is_server() or network_is_moderator() then
        -- do nothing
    else
        djui_chat_message_create("You cannot run this command")
        return true
    end

    ---@type integer | number?
    local index = -1
    -- If the message turns out to be a player index
    if tonumber(msg) then
        index = tonumber(msg)
    elseif msg ~= "" then -- if the message turns out to be a player name
        index = get_global_index_from_name(msg)
    else
        djui_chat_message_create("Empty message")
        return false
    end

    if not index then
        djui_chat_message_create("Invalid name entered")
        return false
    end
    if index < 0 or index > MAX_PLAYERS - 1 then
        djui_chat_message_create("Index out of bounds")
        return false
    end
    local player = gMarioStates[network_local_index_from_global(index)]
    if not is_player_active(player) then
        djui_chat_message_create("Player is not connected or is dead")
        return false
    end
    ptr[1] = player
    return true
end

local function on_packet_recieve(datatable)
    if datatable.die then
        ---@type MarioState
        local m = gMarioStates[0]
        m.health = 255
        local underwater = m.pos.y < m.waterLevel
        set_mario_action(m, (underwater and ACT_WATER_DEATH or ACT_STANDING_DEATH), 0)
    end
end

---@param msg string
local function freeze_chat_command(msg)
    local ptr = {nil}
    if check_valid_player(msg, ptr) then
        if ptr[1].playerIndex ~= 0 then
            network_send_to(ptr[1].playerIndex, true, { freeze = true })
        else
            toggle_frozen()
        end
    end
    return true
end

---@param msg string
local function kill_chat_command(msg)
    local ptr = {nil}
    if check_valid_player(msg, ptr) then
        if ptr[1].playerIndex ~= 0 then
            network_send_to(ptr[1].playerIndex, true, { die = true })
        else
            local m = gMarioStates[0]
            m.health = 255
            set_mario_action(m, ACT_IDLE, 0)
        end
    end
    return true
end

hook_event(HOOK_ON_PACKET_RECEIVE, on_packet_recieve)
hook_event(HOOK_BEFORE_MARIO_UPDATE, freeze_before_mario_update)
hook_event(HOOK_ON_PACKET_RECEIVE, freeze_packet_recieve)
hook_chat_command('freeze', "Freezes a select player in place.", freeze_chat_command)
hook_chat_command("fly", "Gives yourself the wing cap", fly_chat_command)
hook_chat_command('kill', "Type in the name or player index of the player you want to kill.\nCan only be used by the server or any server moderators.", kill_chat_command)