-- name: Auto BLJ
-- description: Automatically BLJ anywhere!

local gMarioStateExtras = {}

for i = 0, (MAX_PLAYERS - 1) do
    gMarioStateExtras[i] = {}

    local m = gMarioStates[i]
    local e = gMarioStateExtras[i]

	e.BLJDelayTime = 1
	e.BLJDelayTimer = 0
	e.LJTimer = 0
end

local function before_mario_update(m)
	local e = gMarioStateExtras[m.playerIndex]

	e.BLJDelayTimer = e.BLJDelayTimer + 1

	if m.action == ACT_LONG_JUMP then
		e.LJTimer = e.LJTimer + 1
	end
	
	if (m.controller.buttonDown & L_TRIG) ~= 0 then
		m.forwardVel = 0
	end

	if (m.controller.buttonDown & A_BUTTON) ~= 0 and (m.controller.buttonDown & Z_TRIG) ~= 0 and m.forwardVel <= 0 and e.LJTimer > 0 then
		if e.BLJDelayTimer > e.BLJDelayTime then
			if (m.action & ACT_FLAG_AIR) ~= 0 then else
				local OldVelY = m.vel.y
				set_mario_action(m, ACT_LONG_JUMP, 0)
				m.vel.y = OldVelY
			end

			e.BLJDelayTimer = 0
		end
	else
		e.LJTimer = 0
	end

	if is_game_paused() and (m.controller.buttonPressed & L_TRIG) ~= 0 then
        m.action = ACT_LAVA_BOOST
        m.health = 0
	end
end

hook_event(HOOK_BEFORE_MARIO_UPDATE, before_mario_update)